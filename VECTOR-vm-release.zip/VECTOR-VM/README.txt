VECTOR VM experimental build

Run VECTOR.vm.lua in a compatible Lua/Luau host.
Complete VECTOR payload compiled to 27,856 custom structured VM instructions.
Creates VECTOR/main.lua for teleport resume. Requires the usual executor APIs and internet for Rayfield.
Initialization passed in Roblox. Gameplay and teleport resume have not been fully validated.
VM changes stack/debug/namecall behavior and can be slower than the regular release.
